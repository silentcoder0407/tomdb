<div class="container text-warning">
  <footer class="page-footer font-small ">
    <div class="row">
      <div class="col footer-copyright text-left py-3"><p class="small text-decoration-none"><a  href="disclaimer.php">Disclaimer</a> &nbsp; <a  href="donate.php">Donate</a></p></div>
      <div class="col footer-copyright text-right py-3">&copy;&nbsp;<?php echo date("Y");?> Made with <i class="text-danger icon ion-heart"></i> by <?php echo $g_gtitle;?> Team</div>
    </div>
  </footer>
</div>





