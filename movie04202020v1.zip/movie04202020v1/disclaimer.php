<?php
include("global_variables.php");
include("nav.php");


?>

<title>Disclaimer<?php echo $g_title; ?></title>


<div class="about">
<center><img class="loginlogo" src="<?php echo $g_logo;?>"/></center><br>
<b><center><div class=""><small><font color="orange"><?php echo $g_gtitle;?></font></small></div></center></b><br>
<p>This site does not store any files on its server. All contents are provided by non-affiliated third parties.</p>


</div>

<?php include ('footer.php');?>
